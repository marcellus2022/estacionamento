<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Usuarios_model extends CI_Model {

    

}
